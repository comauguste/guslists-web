related_ads
===========

<<<<<<< HEAD
Related ads plugin is very easy to use plugin which will show latest related ads on Item page and helps you to reduce bounce rate of your classified portal.
In order to use this plugin, you should enable Auto-embed feature in plugin configuration screen or edit your theme file item.php and add the following line anywhere in the code you want related ads to display
=======
This is a simple Related Ads plugin for Osclass
<<<<<<< HEAD
>>>>>>> Create README.md
=======
>>>>>>> cb28221860b88d0fed5114aa05b2031685659f16
>>>>>>> 0765e1c1d3337d1a3d84f18f6c50c51dc55b5454
